package org.example;

import java.util.Scanner;

class employee1 extends Human {
    // Additional attributes
    private double salary;
    private double startDate;
    private String position;
    private String education;



    @Override
    public String toString() {
        return "employee1{" +
                "salary=" + salary +
                ", startDate=" + startDate +
                ", position='" + position + '\'' +
                ", education='" + education + '\'' +
                '}';
    }
    public void display() {
        System.out.println( "employee1{" +
                "salary=" + salary +
                ", startDate=" + startDate +
                ", position='" + position + '\'' +
                ", education='" + education + '\'' +
                '}');
    }

    public employee1() {
        super();
        // Empty constructor
    }

    // Setter methods
    public void setSalary(double salary)
    {
        this.salary = salary;
    }

    public void setStartDate(double startDate) {

        this.startDate = startDate;
    }

    public void setPosition(String position) {

        this.position = position;
    }

    public void setEducation(String education) {
        this.education = education;
    }

    // Getter methods
    public double getSalary() {

        return salary;
    }

    public double getStartDate()
    {
        return startDate;
    }

    public String getPosition()
    {
        return position;
    }

    public String getEducation()
    {
        return education;
    }
    public void addEmployee(){
        Scanner scanner = new Scanner(System.in);
        Human human1= new Human();
        System.out.println("enter the frist name ");
        human1.setName(scanner.next());

        System.out.println("enter the last name ");
        human1.setLastName(scanner.next());

        System.out.println("enter the age ");
        human1.setAge(scanner.nextInt());
        System.out.println("enter the gander");

        human1.setGender(scanner.next());

        System.out.println("enter the phone nuamber");

        human1.setPhone(scanner.nextInt());

        System.out.println("enter the address");
        human1.setAddress(scanner.next());

        System.out.println("enter your Nationality");
        human1.setNationality(scanner.nextLine());
        System.out.println("enter the Region");
        human1.setRegion(scanner.nextLine());

        employee1 Employee = new employee1();
       // System.out.println("enter the Position");
      //  Employee.setPosition(scanner.nextLine());
       //System.out.println("enter the Education");
        //Employee.setEducation(scanner.nextLine());
        //Employee.setSalary(20000);
        System.out.println("if you want to print data enter 1");
        System.out.println("if you want to get out the program 2");
        int data = scanner.nextInt();
        if(data==1)
            System.out.println(data);




    }

}
/////////////////////////////////




