package org.example;


import java.util.Scanner;


public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        employee1 employee1 = new employee1();
        System.out.println("if you an employee enter 1");
        System.out.println("if you want book ticket 2");
        // int f = scanner.nextInt();


        int emoloyee1 = scanner.nextInt();

        System.out.println(employee1.toString());


        if (emoloyee1 == 1) {
            employee1.addEmployee();


            //          int X = scanner.nextInt();

//                if (X == 1) {
////                    System.out.println("the frist name is " + human1.getName());
////
////                    System.out.println("The last name is " + human1.getLastName());
////
////                    System.out.println("The Age is " + human1.getAge());
////
////                    System.out.println("The gander is " + human1.getGender());
////                    System.out.println("The phone nuamber is " + human1.getPhone());
////                    System.out.println("The phone address is " + human1.getAddress());
////                    System.out.println("your Nationality" + human1.getNationality());
////                    System.out.println("your Region" + human1.getRegion());
////                    System.out.println("enter the Education");
//
//
//                }


        }

    }
}






