package org.example;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

public class BookingAgent extends flightCompany{

    private  int ordeNrumber;
    private String agentName , companyName , companyPlace ;
    private double price;
    private int orderNumber,flightNumber;

    public BookingAgent(String flightCompanyName, String agentName, String companyName, String companyPlace, double id, double price, int orderNumber, int flightNumber, int orderumber, int orderumber1) {
        super(id, flightCompanyName);
        this.agentName = agentName;
        this.companyName = companyName;
        this.companyPlace = companyPlace;
        this.price = price;
        this.orderNumber = orderNumber;
        this.flightNumber = flightNumber;

    }



    public String getAgentName() {
        return agentName;
    }

    public void setAgentName(String agentName) {
        this.agentName = agentName;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getCompanyPlace() {
        return companyPlace;
    }

    public void setCompanyPlace(String companyPlace) {
        this.companyPlace = companyPlace;
    }




    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getOrderNumber() {
        return orderNumber;
    }

    public int getFlightNumber() {
        return flightNumber;
    }

    public void setFlightNumber(int flightNumber) {
        this.flightNumber = flightNumber;
    }


        protected static int totalTickets = 100;
        private static List<String> bookingList = new ArrayList<>();

        public void bookingTicket() {
            System.out.println("Enter the number of tickets needed:");
            Scanner scanner = new Scanner(System.in);
            int tickets = scanner.nextInt();
            if (checkAvailability(tickets)) {
                System.out.print("Enter your name: ");
                agentName = scanner.nextLine();
                System.out.print("Enter your id: ");
                id = scanner.nextDouble();
                System.out.println("Enter the company name:");
                companyName = scanner.nextLine();

                System.out.println("A ticket has been booked by" + agentName + "of id: " + id + "with the company" + companyName);
            } else
                System.out.println(tickets + " tickets unavailable.");
        }

        private boolean checkAvailability(int tickets) {
            return tickets <= totalTickets;
        }

        public void cancelingTicket(String agentName, double id, String companyName) {

            System.out.print("Enter your name: ");
            Scanner scanner = new Scanner(System.in);
            agentName = scanner.nextLine();
            System.out.print("Enter your id: ");
            id = scanner.nextDouble();
            System.out.println("Enter the company name:");
            companyName = scanner.nextLine();

            System.out.println("A ticket has been  canceled by" + agentName + "of id: " + id + "with the company" + companyName);
        }

    }


