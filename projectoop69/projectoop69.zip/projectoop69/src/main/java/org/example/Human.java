package org.example;

import java.util.Scanner;

public class Human extends User {



        protected String  lastName , gender , address , nationality , region ;
        protected int age;
        protected double phone;

        public Human(int id,String Name, String lastName, String gender, String address, String nationality ,String region, int age, double phone) {
            super(id,Name);
            this.lastName = lastName;
            this.gender = gender;
            this.address = address;
            this.nationality = nationality;
            this.region = region;
            this.age = age;
            this.phone = phone;
        }

    public Human() {
        super();
    }


    public String getLastName() {
            return lastName;
        }

        public void setLastName(String lastName) {
            this.lastName = lastName;
        }

        public String getGender() {
            return gender;
        }

        public void setGender(String gender) {
            this.gender = gender;
        }

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public String getNationality() {
            return nationality;
        }

        public void setNationality(String nationality) {
            this.nationality = nationality;
        }

        public String getRegion() {
            return region;
        }

        public void setRegion(String region) {
            this.region = region;
        }

        public int getAge() {
            return age;
        }

        public void setAge(int age) {
            this.age = age;
        }

        public double getPhone() {
            return phone;
        }

        public void setPhone(double phone) {
            this.phone = phone;
        }






    }






