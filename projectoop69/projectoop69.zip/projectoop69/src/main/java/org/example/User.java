package org.example;

public class User {
    protected double id ;
   protected String name ;

    public User() {
    id =0;
    name="";
    }

    public User(int id, String name) {
        this.id = id;
        this.name = name;
    }
     public User(int id){
        this.id=id;



     }
    public double getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
