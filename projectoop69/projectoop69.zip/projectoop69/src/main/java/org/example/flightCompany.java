package org.example;

public class flightCompany extends AboutTheAirport {

protected  String flightCompanyName ;


    public String getFlightCompanyName() {
        return flightCompanyName;
    }

    public void setFlightCompanyName(String flightCompanyName) {
        this.flightCompanyName = flightCompanyName;
    }

    // Parameterized constructor
        public flightCompany(double id, String flightCompanyName) {
            this.id = id;
            this.flightCompanyName = flightCompanyName;

        }



    }

