package org.example;

import java.util.ArrayList;

//import static org.example.BookingAgent.TicketReservationSystem.totalTickets;
import static org.example.BookingAgent.totalTickets;

public class Flight extends flightCompany {



    protected int numOfPassenger = totalTickets;
    int planId,arrivalHour,departureHour;
    private String departureAirport,arrivalAirport;

  /*  public Flight(int num, int passenger, int planId, int arrivalHour, int departureHour, String departureAirport, String arrivalAirport) {
        this.num = num;
        this.passenger = passenger;
        this.planId = planId;
        this.arrivalHour = arrivalHour;
        this.departureHour = departureHour;
        this.departureAirport = departureAirport;
        this.arrivalAirport = arrivalAirport;
    }
*/

    public Flight(double id, String flightCompanyName, int numOfPassenger, int planId, int arrivalHour, int departureHour, String departureAirport, String arrivalAirport) {
        super(id, flightCompanyName);

        this.numOfPassenger= numOfPassenger;
        this.planId = planId;
        this.arrivalHour = arrivalHour;
        this.departureHour = departureHour;
        this.departureAirport = departureAirport;
        this.arrivalAirport = arrivalAirport;
    }





    public int getPassenger() {
        return numOfPassenger;
    }

    public void setNumOfPassenger(int numOfPassenger) {
        this.numOfPassenger = numOfPassenger;
    }

    public int getPlanId() {
        return planId;
    }

    public void setPlanId(int planId) {
        this.planId = planId;
    }

    public int getArrivalHour() {
        return arrivalHour;
    }

    public void setArrivalHour(int arrivalHour) {
        this.arrivalHour = arrivalHour;
    }

    public int getDepartureHour() {
        return departureHour;
    }

    public void setDepartureHour(int departureHour) {
        this.departureHour = departureHour;
    }

    public String getDepartureAirport() {
        return departureAirport;
    }

    public void setDepartureAirport(String departureAirport) {
        this.departureAirport = departureAirport;
    }

    public String getArrivalAirport() {
        return arrivalAirport;
    }

    public void setArrivalAirport(String arrivalAirport) {
        this.arrivalAirport = arrivalAirport;
    }

}





